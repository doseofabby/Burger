INSERT INTO burgers (burger_name, devoured) VALUES ("All Tinted in the Coupe", FALSE);

INSERT INTO burgers (burger_name, devoured) VALUES ("Dollar", FALSE);

INSERT INTO burgers (burger_name, devoured) VALUES ("No Guidance", TRUE);


