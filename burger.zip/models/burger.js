const orm = require('../config/orm');

const burger = {
    select: (cb) => {
        orm.selectAll("burgers", (results) => {
            cb(results);
        });
    },
    create: (column, values, cb) => {
        orm.insertOne("burgers", column, values, (results) => {
            cb(results);
        });
    },
    update: (column, newVal, whereCol, whereVal, cb) => {
        orm.updateOne("burgers", column, newVal, whereCol, whereVal, (results) => {
            cb(results);
        });
    },

}


module.exports = burger;